package mrs.domain.model;

public enum RoleName {
	ADMIN, USER
}